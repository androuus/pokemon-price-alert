# Amazon ETB Monitor — sin PA API

Vigila la ETB de Amazon.es (ASIN B0H8T5GC4W) cada 5 minutos con Playwright.

## Secrets necesarios

En GitHub → Settings → Secrets and variables → Actions crea:

- `TELEGRAM_BOT_TOKEN`
- `TELEGRAM_CHAT_ID`

No pongas estos valores en ningún archivo del repositorio.

## Qué hace

- Abre la página de Amazon con Chromium.
- Intenta aceptar el consentimiento de cookies.
- Lee el precio.
- Comprueba disponibilidad y botón Añadir a la cesta.
- Si está disponible y cuesta 70 € o menos, manda Telegram.
- Evita repetir el aviso mientras siga cumpliendo la condición.
- Si vuelve a superar 70 € (o deja de estar disponible), rearma la alerta.

## Instalación

1. Sube todo el contenido de este ZIP a tu repositorio.
2. Comprueba los dos Secrets.
3. Ve a Actions → Amazon ETB Monitor.
4. Pulsa Run workflow para probarlo.
5. Después quedará programado cada 5 minutos.

## Importante

Amazon puede mostrar CAPTCHA, bloquear automatización o cambiar el HTML. En ese caso el workflow fallará y no debe interpretarse como que el producto no está disponible.

GitHub Actions admite una frecuencia mínima de 5 minutos para `schedule`.
